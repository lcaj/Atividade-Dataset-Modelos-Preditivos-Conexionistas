# Dataset CesarScholl > 2023-04-25 9:21am
https://universe.roboflow.com/object-detection/dataset-cesarscholl

Provided by a Roboflow user
License: CC BY 4.0

